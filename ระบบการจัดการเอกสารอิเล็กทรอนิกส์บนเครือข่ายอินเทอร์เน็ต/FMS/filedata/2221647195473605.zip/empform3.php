<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <!--css-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css" integrity="sha384-zCbKRCUGaJDkqS1kPbPd7TveP5iyJE0EjAuZQTgFLD2ylzuqKfdKlfG/eSrtxUkn" crossorigin="anonymous">
    <!--css font--> 
    <link href="https://fonts.googleapis.com/css2?family=Sarabun:ital,wght@0,200;0,300;0,400;0,500;0,600;1,300;1,400&display=swap" rel="stylesheet">
    
    <!--font awesome 4.7-->
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <!--sweetalert2--> 
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <style>
        body{
            font-family: 'Sarabun', sans-serif;
        }
    </style>
</head>
<body>
    <form method="POST" name="fr_employee" action="" class="form-inline">

    <?php
    include("../connect_db.php");
    //กำหนดค่าเริ่มต้นให้กับตัวแปรและการรับค่า POST
    if(isset($_POST['search_other'])) { $ls_search_other = $_POST['search_other'] ;} else { $ls_search_other = ''; }
    if(isset($_POST['search_name'])) { $ls_search_name = $_POST['search_name'] ;} else { $ls_search_name = ''; }
    if(isset($_GET['action'])) { $ls_action = $_GET['action'] ;} else { $ls_action = ''; }
        //echo $ls_action;
    ?>
    <div class="container">
    <?php 
        if($ls_action==""){
    ?>
    <br>
    <h1>จัดการข้อมูลพนักงาน</h1>
   
    <div class="form-inline">
        <div class="form-group">         
            <select name="search_other" class="form-control">
                <option value="0">ทั้งหมด</option>
                <option value="1">ค้นหาตามรหัส</option>
                <option value="2">ค้นหาตามชื่อ</option>
                <option value="3">ค้นหาตามตำแหน่ง</option>
            </select>
            <?php echo "<script>document.fr_employee.search_other.value=".$ls_search_other."</script>";?>
        </div>
        &nbsp;
        <div class="form-group mr-2"> 
            <input type="text" name="search_name" class="form-control" placeholder="คำที่ต้องการข้อมูล">  
        </div>
        &nbsp;
        <!--<input type="submit" name="btn_search" class="btn btn-success" value="ค้นหา">-->
        <button type="submit" name="btn_search" class="btn btn-success"><i class="fa fa-search"></i> ค้นหา</button>
    </div>

    <?php
        include("../connect_db.php"); 
        //เมื่อมีการคลิกปุ่มชื่อ btn_search
        if(isset($_POST['btn_search']))
        {
            $ls_search_name = $_POST['search_name'];
            $ls_search_other = $_POST['search_other'];

            

            $query = "select * from employee where";

            if($ls_search_other =='1') 
            {
                $query.= " employeeID like '%".$ls_search_name."%'";
            }   else if($ls_search_other =='2')
                {
                $query.= " name like '%".$ls_search_name."%'";
                }
                else if($ls_search_other =='3')
                {
                $query.= " job like '%".$ls_search_name."%'";
                }
            else {
                $query.= " job like '%".$ls_search_name."%'";
            }

            $query.=" order by employeeID";
            //echo $query;
        } else {
            $query = "select * from employee";
        }
            echo "<br>"; //ขึ้นบรรทัดใหม่
            ?>
                <table class="table table-bordered table-striped">
                    <tr>
                        <td colspan="6">
                            <a href="empform3.php?action=Add" class="btn btn-primary"><i class="fa fa-plus"></i> เพิ่มข้อมูลพนักงาน</a></td>
                    </tr>
                <thead>
                    <tr>
                        <td>รหัสพนักงาน</td>
                        <td>ชื่อ-สกุล</td>
                        <td>ตำแหน่ง</td>
                        <td>เงินเดือน</td>
                        <td>แผนก</td>
                        <td>#</td>
                     
                    </tr>
                </thead>
                    <?php
        
                    $result = mysqli_query($conn, $query);
                    while($data = mysqli_fetch_array($result))
                    {
                    ?>              
                    <tr>
                        <td><?php echo $data['employeeID']; ?></td>
                        <td><?php echo $data['name']; ?></td>
                        <td><?php echo $data['job']; ?></td>
                        <td><?php echo $data['salary']; ?></td>
                        <td><?php echo $data['departmentID']; ?></td>
                        <td>
                            <a href="empform3.php?action=edit&id=<?php echo $data['employeeID'];?>" class="btn btn-warning"><i class="fa fa-pencil"></i> แก้ไข</a> 
                            <a href="empform3.php?action=del&id=<?php echo $data['employeeID'];?>" class="btn btn-danger"><i class="fa fa-trash"></i> ลบ</a>
                        </td>
                    </tr>
                    <?php
                    }
                    ?>
                </table>

</div>
<?php } ?>
    <?php 
        if($ls_action=="Add"){
    ?>
        <div class="container">
            <h1>เพิ่มข้อมูลพนักงาน</h1>
            <form method="POST">

                <div class="form-group">
                    <label for="">รหัสพนักงาน</label>   
                    <input type="text" name="emp_id" class="form-control">
                </div>

                <div class="form-group">
                    <label for="">ชื่อพนักงาน</label>   
                    <input type="text" name="emp_name" class="form-control">
                </div>

                <div class="form-group">
                    <label for="">ตำแหน่งงาน</label>   
                    <input type="text" name="emp_job" class="form-control">
                </div>

                <div class="form-group">
                    <label for="">เงินเดือน</label>   
                    <input type="number" name="emp_salary" class="form-control">
                </div>

                <div class="form-group">
                    <label for="">แผนก</label>      
                    <select name="depart_id" class="form-control">
                        <?php 
                        //ดึงข้อมูลแผนก
                        include("../connect_db.php");
                        $query_depart = "SELECT * FROM department";
                        $result_depart = mysqli_query($conn, $query_depart);
                        while($data_depart = mysqli_fetch_array($result_depart))
                        {
                        ?>
                        <option value="<?php echo $data_depart['departmentID'];?>"><?php echo $data_depart['name'];?></option>
                        <?php 
                        }
                        ?>
                    </select>
            <br>
            <input type="submit" name="btn_insert" class="btn btn-primary" value="บันทึกข้อมูล">
        <br>
            <a href="empform3.php" class="btn btn-info">กลับหน้าหลัก</a>
            </form>

            <?php
            
            //เมื่อมีการคลิกปุ่ม btn_insert 
            if(isset($_POST['btn_insert'])){

            
                    //isset คือ คำสั่ง PHP ไว้ตรวจสอบการมีอยู่ของตัวแปร 
                    if(isset($_POST['emp_id'])) { $ls_emp_id = $_POST['emp_id'] ;} else { $ls_emp_id = ''; }
                    if(isset($_POST['emp_name'])) { $ls_emp_name = $_POST['emp_name'] ;} else { $ls_emp_name = ''; }
                    if(isset($_POST['emp_job'])) { $ls_emp_job = $_POST['emp_job'] ;} else { $ls_emp_job = ''; }
                    if(isset($_POST['emp_salary'])) { $ls_emp_salary = $_POST['emp_salary'] ;} else { $ls_emp_salary = ''; }
                    if(isset($_POST['depart_id'])) { $ls_depart_id = $_POST['depart_id'] ;} else { $ls_depart_id = ''; }
                    
                    
                    $sql = "INSERT INTO employee 
                    (
                        employeeID, 
                        NAME, 
                        job, 
                        Salary, 
                        departmentID 
                    ) 
                    VALUES 
                    (
                        '".$ls_emp_id."',
                        '".$ls_emp_name."',
                        '".$ls_emp_job."',
                        '".$ls_emp_salary."',
                        '".$ls_depart_id."'

                    ) ";
                    $result = mysqli_query($conn, $sql);
                    if($result){

                    
                            echo "<script>

                            Swal.fire(
                                'สำเร็จ!',
                                'บันทึกเรียบร้อยแล้ว!',
                                'success'
                            )
                            </script>";
                            //หลังจากบันทึกให้ไปยังหน้าที่ต้องการ
                            
                            //header( "location: empform3.php" );
        
                    }
            }

            ?>
            
            </div>
        <?php 
    }   ?>

    <?php 
        if($ls_action=="del"){
            echo "ลบ";
            echo $emp_id = $_GET['id'];
            //รหัสพนักงาน = 11
            echo $query = "DELETE FROM employee where employeeID = '".$emp_id."'";
            $result_del = mysqli_query($conn, $query); //ส่ังให้ทำงาน
            if($result_del){
                echo "<script> alert('ลบข้อมูลเรียบร้อยแล้ว');</script>";
                echo header("refresh:2; url=empform3.php");
            }
            //
        }

    ?>
    </form>
</body>
</html>